// Peyton 1/15 -- line comment
public class songslyrics {

	public static void main(String[] args) {
 System.out.println("Been dreaming of getting away since I dont know");
 System.out.println("Ain't no better time than now, for mexico");
 System.out.println("No Shoes, No Shirt, No problems");
	
	}

}
