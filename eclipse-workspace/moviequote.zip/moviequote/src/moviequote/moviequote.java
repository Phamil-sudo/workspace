// Peyton 1/15 --line comment 
		package moviequote;

public class moviequote {

	public static void main(String[] args) {
 		System.out.println("If the boot fits");
 		System.out.println("Woody");
 		System.out.println("Toy Story");
 		System.out.println("1999");
	}
}
